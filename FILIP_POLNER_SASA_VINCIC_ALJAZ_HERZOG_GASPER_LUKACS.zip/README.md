# FireFoxEmailExtension


1. Start by opening Firefox and typin about:debugging,
2. Open tab This Firefox
3. Click Load Temporary Add-on and load manifest.json
